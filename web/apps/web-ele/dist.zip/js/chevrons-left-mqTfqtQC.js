import{c as e}from"./bootstrap-BdGfuCVl.js";const a=e("chevrons-left",[["path",{d:"m11 17-5-5 5-5",key:"13zhaf"}],["path",{d:"m18 17-5-5 5-5",key:"h8a8et"}]]);export{a as C};
