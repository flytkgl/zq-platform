import{c as e}from"./bootstrap-BdGfuCVl.js";const a=e("panel-left",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M9 3v18",key:"fh3hqa"}]]);export{a as P};
