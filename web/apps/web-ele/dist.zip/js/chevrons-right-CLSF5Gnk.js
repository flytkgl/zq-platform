import{c as e}from"./bootstrap-BdGfuCVl.js";const o=e("chevrons-right",[["path",{d:"m6 17 5-5-5-5",key:"xnjwq"}],["path",{d:"m13 17 5-5-5-5",key:"17xmmf"}]]);export{o as C};
