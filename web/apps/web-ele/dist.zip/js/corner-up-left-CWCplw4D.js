import{c as e}from"./bootstrap-BdGfuCVl.js";const n=e("corner-up-left",[["polyline",{points:"9 14 4 9 9 4",key:"881910"}],["path",{d:"M20 20v-7a4 4 0 0 0-4-4H4",key:"1nkjon"}]]);export{n as C};
