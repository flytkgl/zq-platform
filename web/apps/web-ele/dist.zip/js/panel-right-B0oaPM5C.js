import{c as t}from"./bootstrap-BdGfuCVl.js";const a=t("panel-right",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M15 3v18",key:"14nvp0"}]]);export{a as P};
