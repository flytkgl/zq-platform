import{c as e}from"./bootstrap-BdGfuCVl.js";const t=e("code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]]);export{t as C};
