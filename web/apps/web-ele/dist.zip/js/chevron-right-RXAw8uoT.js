import{c as t}from"./bootstrap-BdGfuCVl.js";const h=t("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
