import"./bootstrap-BdGfuCVl.js";/* empty css                */import"../jse/index-index-CTFmELYh.js";
